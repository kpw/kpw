UPDATE `creature_template` SET `minmana`='30000',`maxmana`='30000' WHERE (`entry`='22120');
UPDATE `creature_template` SET `InhabitType`='3' WHERE (`entry`='21217');
