INSERT INTO spell_script_target VALUES (38112, 1, 21212);
