/* Copyright (C) 2006 - 2008 ScriptDev2 <https://scriptdev2.svn.sourceforge.net/>
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* ScriptData
SDName: Instance_Serpent_Shrine
SD%Complete: 0
SDComment: VERIFY SCRIPT
EndScriptData */

#include "../../../sc_defines.h"
#include "../../../../../../game/GameObject.h"

#include "def_serpent_shrine.h"
#include "../../../../../../game/TargetedMovementGenerator.h"


#define ENCOUNTERS 6

/* Serpentshrine cavern encounters:
0 - Hydross The Unstable event
1 - Leotheras The Blind Event
2 - The Lurker Below Event
3 - Fathom-Lord Karathress Event
4 - Morogrim Tidewalker Event
5 - Lady Vashj Event
*/

//Lurker Event defines
#define SCALDING_WATER			37284
#define MOB_COILFANG_FRENZY		21508
#define MOB_HONOR_GUARD			21218	//count should be 6 (have 6 platforms around lurker
#define BOSS_THE_LURKER_BELOW	21217

#define LURKER_DESPAWN_TIME		110000

float LorkerPos[4] = 
{
    40.4058, 
	-417.108, 
	-21.5911, 
	1
};
//Lurker Event defines end

struct MANGOS_DLL_DECL instance_serpentshrine_cavern : public ScriptedInstance
{
    instance_serpentshrine_cavern(Map *Map) : ScriptedInstance(Map) {Initialize();};

	uint64 Lurker;
    uint64 Sharkkis;
    uint64 Tidalvess;
    uint64 Caribdis;
    uint64 LadyVashj;
    uint64 Karathress;
    uint64 KarathressEvent_Starter;

	GameObject *BridgeConsole;
	GameObject *BridgePart1;
	GameObject *BridgePart2;
	GameObject *BridgePart3;

	uint64 MinDmg;
	uint64 MaxDmg;

	uint64 Dummys[8];
	uint64 Center;
    bool ShieldGeneratorDeactivated[4];

    bool Encounters[ENCOUNTERS];

	bool open;

	//Lurker Event vars
	bool LurkerEvent;
	bool IsVisible;
	uint32 WaterTimer;
	uint32 EventTimer;
	Creature* Fishy;
	Creature* TheLurkerBelow;
	uint32 Counter;
	std::list<Creature*>MustBeKilled;
	//Lurker Event vars end

	//Lurker Event instance Update
	void Update(uint32 diff)
	{
		//lurker platform checkers
		if (EventTimer < diff)
		{
			uint32 Dead = 0;
			Creature* TempSummoner = NULL;	
			if (!MustBeKilled.empty())
			{			
				for (std::list<Creature*>::iterator i = MustBeKilled.begin(); i != MustBeKilled.end(); ++i)
				{
					if ((*i))
					{
						TempSummoner = (*i);
						if ((*i)->isDead())
							Dead++;
					}
				}
			}
			if (Dead >= MustBeKilled.size() && Dead > 0)
			{
				//'spawn' lurker  && no more fish				
				if (TempSummoner)
				{
					if (!LurkerEvent)
					{
						//TempSummoner->Yell("The.. water..",LANG_UNIVERSAL,0);
						std::list<Player*>players =instance->GetPlayers();
						for (std::list<Player*>::iterator i = players.begin(); i != players.end(); ++i)
						{
							if ((*i)->GetSession())
								(*i)->GetSession()->SendNotification("The water started to boil.");
						}
						if (TheLurkerBelow && !IsVisible)
						{
							//TheLurkerBelow = TempSummoner->SummonCreature(BOSS_THE_LURKER_BELOW,LorkerPos[0],LorkerPos[1],LorkerPos[2],LorkerPos[3],TEMPSUMMON_CORPSE_TIMED_DESPAWN,LURKER_DESPAWN_TIME);	//2hours (but its manual despawn, so nwm..)
							//11686 invis model	//20216 lurker model //SetVisibility(VISIBILITY_OFF);
							//TheLurkerBelow->SetUInt32Value(UNIT_FIELD_FLAGS, UNIT_FLAG_NOT_SELECTABLE);

							IsVisible = true;
							TheLurkerBelow->RemoveFlag(UNIT_FIELD_FLAGS, UNIT_FLAG_NOT_SELECTABLE);
							TheLurkerBelow->SetVisibility(VISIBILITY_ON);
							TheLurkerBelow->setFaction(14);

							//if (TheLurkerBelow)
							//	TheLurkerBelow->SetRespawnTime(7*24*60*60*1000);
						}	
					}
				}
				LurkerEvent = true;
			}else{
				//platforms respawned, fish come back
				LurkerEvent = false;
			}
			EventTimer = 5000;
		}else EventTimer-= diff;
		//water event
		if (WaterTimer < diff)
		{
			std::list<Player*>players =instance->GetPlayers();
			for (std::list<Player*>::iterator i = players.begin(); i != players.end(); ++i)
			{
				if (!(*i)->GetSession() || !(*i)->isAlive())
					continue;
				if ((*i)->IsInWater())
				{
					if (LurkerEvent)
					{
						if (!(*i)->HasAura(SCALDING_WATER,0))
							(*i)->CastSpell((*i),SCALDING_WATER,true);
					}else{
						//spawn fish
						if (Counter >= 5)
						{
							Fishy = (*i)->SummonCreature(MOB_COILFANG_FRENZY,(*i)->GetPositionX(),(*i)->GetPositionY(),(*i)->GetPositionZ(),(*i)->GetOrientation(),TEMPSUMMON_TIMED_DESPAWN_OUT_OF_COMBAT,15000);
							if (Fishy)
							{
								Fishy->Attack((*i));
							}
							Counter = 0;
						}
					}
				}else{
					if ((*i)->HasAura(SCALDING_WATER,0) && !(*i)->HasMovementFlags(MOVEMENTFLAG_JUMPING))
						(*i)->RemoveAurasDueToSpell(SCALDING_WATER);
				}
			}
			Counter++;
			if (Counter > 3600)
				Counter = 0;
			WaterTimer = 1000;
		}else WaterTimer -= diff;
	}
	//Lurker Event instance Update end
    void Initialize()
    {		
		//Lurker Event
		LurkerEvent = false;
		IsVisible = false;
		WaterTimer = 1000;
		Fishy = NULL;
		TheLurkerBelow = NULL;
		Counter = 0;
		MustBeKilled.clear();
		EventTimer = 5000;
		//Lurker Event end

		Lurker = 0;
        Sharkkis = 0;
        Tidalvess = 0;
        Caribdis = 0;
        LadyVashj = 0;
        Karathress = 0;
        KarathressEvent_Starter = 0;

        ShieldGeneratorDeactivated[0] = false;
        ShieldGeneratorDeactivated[1] = false;
        ShieldGeneratorDeactivated[2] = false;
        ShieldGeneratorDeactivated[3] = false;

		MinDmg = 0;
		MaxDmg = 0;

		open = false;

        for(uint8 i = 0; i < ENCOUNTERS; i++)
            Encounters[i] = false;

		for(uint8 i = 0; i < 8; i++)
			Dummys[i] = 0;

		Center = 0;
    }

    bool IsEncounterInProgress() const 
    {
        for(uint8 i = 0; i < ENCOUNTERS; i++)
            if(Encounters[i]) return true; 

        return false;
    }
	void OpenGO(GameObject *go)
    {
        //open the door
        go->SetUInt32Value(GAMEOBJECT_FLAGS, 33);

        go->SetUInt32Value(GAMEOBJECT_STATE, 0);
    }
	void OnObjectCreate(GameObject *go)
    {
        switch(go->GetEntry())
        {
			case 184568:
            BridgeConsole = go;
            break;

            case 184203:
            BridgePart1 = go;
            break;

            case 184204:
            BridgePart2 = go;
            break;

			case 184205:
            BridgePart3 = go;
            break;
        }
    }
    void OnCreatureCreate(Creature *creature, uint32 creature_entry)
    {
        switch(creature_entry)
        {
			//Lurker Event
			case MOB_HONOR_GUARD:
				MustBeKilled.push_back(creature);
			break;
			//Lurker Event end

			case 41000:
				for(uint8 i = 0; i < 8; i++)
				{
					if (Dummys[i] == 0)
					{
						Dummys[i] = creature->GetGUID();
						return;
					}
				}
            break;

			case 41001:
            Center = creature->GetGUID();
            break;

            case 21212:
				{
					const CreatureInfo *cinfo = creature->GetCreatureInfo();
					MinDmg = cinfo->mindmg;
					MaxDmg = cinfo->maxdmg;
					LadyVashj = creature->GetGUID();
					break;
				}

            case 21214:
                Karathress = creature->GetGUID();
                break;

            case 21966:
                Sharkkis = creature->GetGUID();
                break;

            case 21965:
                Tidalvess = creature->GetGUID();
                break;

            case 21964:
                Caribdis = creature->GetGUID();
                break;

			case 21217:
				Lurker = creature->GetGUID();
				TheLurkerBelow = creature;
				TheLurkerBelow->SetUInt32Value(UNIT_FIELD_FLAGS, UNIT_FLAG_NOT_SELECTABLE);
				TheLurkerBelow->SetVisibility(VISIBILITY_OFF);
				TheLurkerBelow->setFaction(35);
				break;
        }
    }

    void SetData64(uint32 type, uint64 data)
    {
        if(type == DATA_KARATHRESSEVENT_STARTER)
            KarathressEvent_Starter = data;
		if(type == DATA_MinDmg)
            MinDmg = data;
		if(type == DATA_MaxDmg)
            MaxDmg = data;
    }

    uint64 GetData64(uint32 identifier)
    {
        switch(identifier)
        {
			case DATA_SHARKKIS:
                return Sharkkis;
			case DATA_Dummy0:
				return Dummys[0];
			case DATA_Dummy1:
				return Dummys[1];
			case DATA_Dummy2:
				return Dummys[2];
			case DATA_Dummy3:
				return Dummys[3];
			case DATA_Dummy4:
				return Dummys[4];
			case DATA_Dummy5:
				return Dummys[5];
			case DATA_Dummy6:
				return Dummys[6];
			case DATA_Dummy7:
				return Dummys[7];
			case DATA_Center:
				return Center;
			case DATA_MinDmg:
				return MinDmg;
			case DATA_MaxDmg:
				return MaxDmg;

            case DATA_TIDALVESS:
               return Tidalvess;

            case DATA_CARIBDIS:
               return Caribdis;

            case DATA_LADYVASHJ:
               return LadyVashj;

            case DATA_KARATHRESS:
               return Karathress;

            case DATA_KARATHRESSEVENT_STARTER:
               return KarathressEvent_Starter;
        }
        return 0;
    }
	
    void SetData(uint32 type, uint32 data)
    {
        switch(type)
        {
			case DATA_ConsoleClick:
				if(BridgePart1 && BridgePart2 && BridgePart3)
				{
					if (!open)
					{
						OpenGO(BridgePart1);
						OpenGO(BridgePart2);
						OpenGO(BridgePart3);
						OpenGO(BridgeConsole);
						
						open = true; 
					}					
				}
				break;

            case DATA_HYDROSSTHEUNSTABLEEVENT:
                Encounters[0] = (data) ? true : false;
                break;


            case DATA_LEOTHERASTHEBLINDEVENT:
                Encounters[1] = (data) ? true : false;
                break;

            case DATA_THELURKERBELOWEVENT:
                Encounters[2] = (data) ? true : false;
                break;

            case DATA_KARATHRESSEVENT:
                Encounters[3] = (data) ? true : false;
                break;

            case DATA_MOROGRIMTIDEWALKEREVENT:
                Encounters[4] = (data) ? true : false;
                break;

            //Lady Vashj
            case DATA_LADYVASHJEVENT:
                if(data == 0)
                {
                    ShieldGeneratorDeactivated[0] = false;
                    ShieldGeneratorDeactivated[1] = false;
                    ShieldGeneratorDeactivated[2] = false;
                    ShieldGeneratorDeactivated[3] = false;
                }
                Encounters[5] = (data) ? true : false;
                break;

            case DATA_SHIELDGENERATOR1:
                ShieldGeneratorDeactivated[0] = (data) ? true : false;
                break;

            case DATA_SHIELDGENERATOR2:
                ShieldGeneratorDeactivated[1] = (data) ? true : false;
                break;

            case DATA_SHIELDGENERATOR3:
                ShieldGeneratorDeactivated[2] = (data) ? true : false;
                break;

            case DATA_SHIELDGENERATOR4:
                ShieldGeneratorDeactivated[3] = (data) ? true : false;
                break;
        }
    }

    uint32 GetData(uint32 type)
    {
        switch(type)
        {
            case DATA_HYDROSSTHEUNSTABLEEVENT:
                return Encounters[0];

             case DATA_LEOTHERASTHEBLINDEVENT:
                return Encounters[1];

             case DATA_THELURKERBELOWEVENT:
                return Encounters[2];

             case DATA_KARATHRESSEVENT:
                return Encounters[3];

             case DATA_MOROGRIMTIDEWALKEREVENT:
                return Encounters[4];

            //Lady Vashj
             case DATA_LADYVASHJEVENT:
                return Encounters[5];

             case DATA_SHIELDGENERATOR1:
                return ShieldGeneratorDeactivated[0];

             case DATA_SHIELDGENERATOR2:
                return ShieldGeneratorDeactivated[1];

             case DATA_SHIELDGENERATOR3:
                return ShieldGeneratorDeactivated[2];

             case DATA_SHIELDGENERATOR4:
                return ShieldGeneratorDeactivated[3];

             case DATA_CANSTARTPHASE3:
                if(ShieldGeneratorDeactivated[0] && ShieldGeneratorDeactivated[1] && ShieldGeneratorDeactivated[2] && ShieldGeneratorDeactivated[3])
                    return 1;
                break;
        }

        return 0;
    }
};

InstanceData* GetInstanceData_instance_serpentshrine_cavern(Map* map)
{
    return new instance_serpentshrine_cavern(map);
}
bool GOHello_go_bridge_console(Player *player, GameObject* _GO)
{
    ScriptedInstance *pInstance = (_GO->GetInstanceData()) ? ((ScriptedInstance*)_GO->GetInstanceData()) : NULL;

	if (pInstance)
	{
		pInstance->SetData(DATA_ConsoleClick,0);
		//_GO->TextEmote("Click..", 0);
	}
    return true;
}
void AddSC_instance_serpentshrine_cavern()
{
    Script *newscript;
    newscript = new Script;
    newscript->Name = "instance_serpent_shrine";
    newscript->GetInstanceData = GetInstanceData_instance_serpentshrine_cavern;
    m_scripts[nrscripts++] = newscript;

    newscript = new Script;
    newscript->Name="go_bridge_console";
    newscript->pGOHello = &GOHello_go_bridge_console;
    m_scripts[nrscripts++] = newscript;
}
